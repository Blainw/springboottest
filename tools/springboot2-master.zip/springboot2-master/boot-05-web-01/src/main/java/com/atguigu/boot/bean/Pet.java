package com.atguigu.boot.bean;

import lombok.Data;

@Data
public class Pet {

    private String name;
    private Integer age;

}
