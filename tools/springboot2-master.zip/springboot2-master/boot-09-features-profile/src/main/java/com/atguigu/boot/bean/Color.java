package com.atguigu.boot.bean;

public class Color {
}
